export enum ContractEnum {
  TTDai = 'tt-dai',
  TTUsdt = 'tt-usdt',
  DoubleOrNothing = 'doubleOrNothing'
}
